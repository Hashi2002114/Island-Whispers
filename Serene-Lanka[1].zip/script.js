console.log("Serene Lanka website loaded successfully!");

// Future: Add image modal or scroll animation here
